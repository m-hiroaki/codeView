// GUI_STARTUP 日本語 😀
class StartupFixture
{
    // original content
}
