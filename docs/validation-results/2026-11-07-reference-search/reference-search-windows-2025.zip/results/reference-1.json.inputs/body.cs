class Target {}
// Target target TargetSuffix
var x = "Target";